#!/usr/bin/env python
from random import randint
from brain_games.cli import welcome_user
from brain_games.mechanics import game
from brain_games.mechanics import brain_prime
from sympy import isprime

def main():
    print('Welcome to the Brain Games!')
    name = welcome_user()
    print(f'Hello, {name}')
    ok = brain_prime()
    if ok:
        print(f'Congratulations, {name}')

if __name__ == '__main__':
    main()
