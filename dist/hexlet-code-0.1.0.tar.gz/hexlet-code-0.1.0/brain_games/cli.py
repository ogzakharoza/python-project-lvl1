
def welcome_user():

    name = input('Введи своё имя ')

    return name 
