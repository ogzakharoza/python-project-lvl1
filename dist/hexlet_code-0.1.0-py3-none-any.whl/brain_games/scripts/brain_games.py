#!/usr/bin/env python
import prompt
def main():
    print('Welcome to the Brain Games!')
if __name__ == '__main__':
    main()
def welcome_user():
    name = prompt.string('Введите ваше имя: ')
    print(f'hello + {name}')
if __name__ == '__main__':
    main()
