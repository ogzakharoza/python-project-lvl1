#!/usr/bin/env python
from brain_games.mechanics import start
from brain_games.games import prime


def main():

    return start(prime)


if __name__ == '__main__':
    main()
